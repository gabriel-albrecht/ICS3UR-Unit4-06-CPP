// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program calculates squares

#import <iostream>

int main() {
    int red = 0;
    int green = 0;
    int blue = 0;

    for (red = 0; red <= 255; red) {
        for (green = 0; green <= 255; green) {
            for (blue = 0; blue <= 255; blue) {
                std::cout << "RGB(" << red << "," << green << "," << blue
                << ")" << std::endl;
                blue += blue + 1;
            } green += 1;
        } red += 1;
    }
}
